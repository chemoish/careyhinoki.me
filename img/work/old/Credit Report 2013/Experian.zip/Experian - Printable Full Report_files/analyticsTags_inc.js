s.server = window.location.hostname;
s.channel = 'eCaps';
s.prop14 = 'eCaps';
s.eVar10 = 'eCaps';
var s_code=s.t();if(s_code)document.write(s_code);