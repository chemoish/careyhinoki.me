
var requiredList   = [0,2,5,10,11,12,13,19,20,21,22,23,28,29,30,31]
var xalphaList     = [0,1,2,3,9,11,21,25,28,33]
var numberList     = []
var phoneList      = [8]
var zipList        = [13,23,27,35]
var socNumList     = [5]
var creditCardList = [30]
var expDateList    = [31]
var dateList       = [7,37]
var alphaNumList   = [10,20,24,39]


var abbrevReqList    = [5, 10, 12, 13, 19]
var invList          = [10]


var disputeReqList    = [5, 12, 13, 19]
var reportIdList = [19]




function nonDisputableItemSelected()
{
	if( reseller != null && reseller == true )
	{
		alert("An investigation is already in progress for this item. Investigations may take up to 30 days. We will send you the results once we receive them.");
	}
	else
	{
		alert("An investigation is already in progress for this item. Investigations may take up to 30 days (45 days if you are disputing information in your annual free credit report). We will send you the results once we receive them.");
	}
}


function unableToDisputeItem()
{
	if( reseller != null && reseller == true )
	{
		alert("You cannot dispute this item online. Click on the Contact us link on the Summary page of the credit report for a form that you must use to write to us, and include any documents that may support your customer\'s claim.\n\nNOTE: You must use the Contact us form and mail it to the address on the form in order to receive the results of your customer\'s investigations as required by the Fair and Accurate Credit Transactions Act. Do not give the form or our address to your customer or consumer.");
	}
	else
	{
		alert("We need further information from you in order to process your dispute on this particular item. Please call us at 1 800 493 1058 for assistance.");
	}
}

function experianInquiry()
{ 
	alert("Each time a credit reporting agency accesses your credit file to send you a copy of the report or to dispute items, an inquiry will appear on your credit report. Inquiries may remain on file for two years. These inquiries show only on the credit report sent to you, not to credit grantors.");

}

function experianInquiryNonCDI()
{ 
	alert("Each time a credit reporting agency accesses your credit file to send you a copy of the report or to dispute items, an inquiry will appear on your credit report. Inquiries may remain on file for two years. These inquiries show only on the credit report sent to you, not to credit grantors.");

}

function experianInquiry2()
{ 
	alert("According to the Fair Credit Reporting Act, businesses with a permissible purpose may review your information even if you have not applied for credit with them. Some examples of reasons for review are: your current creditors to monitor your accounts, other creditors who want to offer you preapproved credit, an employer who wishes to extend an offer of employment, and a potential investor in assessing the risk of a current credit obligation. These requests may display for two years; however, we do not display these requests to anyone other than you, and they do not impact your creditworthiness.");

}



var minAge = 14
var maxAge = 121




function y2k(number) { return (number < 1000) ? number + 1900 : number; }


function isDate (dateString) {
    
	tempArray = new Array()
    tempArray = dateString.split("/");

	if ( !isNumber(tempArray[0]) || !isNumber(tempArray[1]) || !isNumber(tempArray[2]) )
		return false;

	month = parseInt(tempArray[0]-1,10);
	day   = parseInt(tempArray[1],10);
	year  = parseInt(tempArray[2],10);
	
    var test = new Date(year,month,day);
    if ( (y2k(test.getYear()) == year) &&
         (month == test.getMonth()) &&
         (day == test.getDate()) )
        return true;
    else
        return false;
}


function makeDate(dateString){
  if (isDate(dateString)){
    
	tempArray = new Array()
    tempArray = dateString.split("/");
  
	month = parseInt(tempArray[0]-1,10);
	day   = parseInt(tempArray[1],10);
	year  = parseInt(tempArray[2],10);
	
    var test = new Date(year,month,day);
    
	return test;
    
  }
  
  return -1;
  
}


function isMinMaxAge(dateOfBirthString){
  
  enteredDate = new Date(dateOfBirthString);
  today = new Date();
  
  yearDifference = today.getFullYear() - enteredDate.getFullYear();
  
  if ((yearDifference > minAge) && (yearDifference < maxAge))  {
  	return true; 
  } 
  else {
	  	if (yearDifference == minAge) {
		
	  		if (enteredDate.getMonth() < today.getMonth()) {
				return true;
			}
			else if (enteredDate.getMonth() > today.getMonth()) {
				return false;
			} 
			else {
				
				if (enteredDate.getDate() <= today.getDate()) {
					return true;
				} 
				else {
					return false;
				}
			}
		}
		
		else if (yearDifference == maxAge) {
			if (enteredDate.getMonth() > today.getMonth()) {
				return true;
			}
			else if (enteredDate.getMonth() < today.getMonth()) {
				return false;
			}
			else {
				if (enteredDate.getDate() > today.getDate()) {
					return true;
				}
				else {
					return false;
				}
				
			}
		}
		else {
			return false;
		}
	}		
}	



function selectCheck(menu){

  if (menu.selectedIndex == 0){
    alert("In order to request an investigation of this item, you must select a reason that explains why you believe the information is inaccurate.");
	return false;
  }
  
  return true;

}


function isXAlpha(testString){ 
  for (i=0;i<testString.length;i++){
	c = testString.substr(i,1);
	
	if (! (  (c >= "a" && c <= "z") || (c >= "A" && c <= "Z" ) || (c == " ") || (c == "-")  ) )
	{
		return false;
	}
  }
  return true;
}


function isAlphaNum(testString){ 
  
  for (i=0;i<testString.length;i++){
	c = testString.substr(i,1);
	if (!((c >= "a" && c <= "z") || (c >= "A" && c <= "Z" ) || (c >= "0" && c <="9") || c == " " || c == "-" || c =="#" || c=="." || c =="/")){
		return false;
	}
  }
  return true;
}



function isXAlphaNum(testString){ 
  
  for (i=0;i<testString.length;i++){
	c = testString.substr(i,1);
	if (!( (c >= "a" && c <= "z") || (c >= "A" && c <= "Z" ) || isNumber(c) || c == " " || c == "-")){
		return false;
	}
  }
  return true;
}



function isNumber(testNumber){ 
      
      while (testNumber.indexOf("0")==0){ 

        testNumber=testNumber.substr(1,testNumber.length-1);

      }

      var tempNumber = parseInt(testNumber);

      if (isNaN(testNumber)){

        return false;
    
      }

      tempNumber=tempNumber.toString();

      if (tempNumber != testNumber){

        return false;
    
      }
  
      return true;

}




function additionalPartialFill(cookieParm){

  if( (cookieParm[24][1] != "") && (cookieParm[25][1] != "") && (cookieParm[26][1] != "")&& (cookieParm[27][1] != "") ){
    	return false;
  }
  	
  if( (cookieParm[24][1] != "") || (cookieParm[25][1] != "") || (cookieParm[26][1] != "")|| (cookieParm[27][1] != "") ){
    return true;
  }
  return false;
}



function cardPartialFill(cookieParm){

  if((cookieParm[32][1] != "") && (cookieParm[33][1] != "") && (cookieParm[34][1] != "")&&(cookieParm[35][1] != "")){
  
    return false;
  }	
  if((cookieParm[32][1] != "") || (cookieParm[33][1] != "") || (cookieParm[34][1] != "")||(cookieParm[35][1] != "")){
  
    return true;
  }
  
   return false;

}

function get_radio_value (radio_array){

    var i;

    for (i = 0; i < radio_array . length; i++)

      if (radio_array [i] . checked){

        return radio_array [i] . value;

      }

      return null;

}


function radio_toggle(choiceName, radioValue){

  document.submitForm[choiceName].value = radioValue;
}

function radio_toggle_freeze(choiceName, radioValue){

  document.submitForm[choiceName].value = radioValue;
}

function isBlank(parmString){ 

      for(i=0;i<parmString.length;i++){

        if (parmString.charAt(i)!=" " && parmString.charAt(i)!="/"){

          return false;

        }     

      }

      return true;

}


function isSSN(parmSSN){

  var tempArray = new Array()
  tempArray = parmSSN.split("/");
  
  parmSSN = tempArray[0] + tempArray[1] + tempArray[2];
  
  if (!isNumber(parmSSN) || (parmSSN.length != 9)){
    return false;
  }
  
  return true;

}



function isZip(myZip){
	  
      if (myZip.indexOf(" ") >= 0)
	     return false; 

      if (isNumber(myZip)){

        var testLength = myZip.length;
      
       
        if ((testLength==5) || (testLength==9)){

          return true;

        }

      }
     
      return false;
    
}

function isInList(listElement, myList){ 

  for ( i=0;i<myList.length;i++ ){
	
    if ( myList[i] == listElement){
	  	 
	   return true;
	   
	}
  
  }
  
  return false;

}

function isPhone(phoneNum){

  var tempArray = new Array();
  tempArray = phoneNum.split("/");

  var areaCode = tempArray[0]
  var firstNum = tempArray[0].substr(0,1)
  var prefix   = tempArray[1]
  
  phoneNum = tempArray[0] + tempArray[1] + tempArray[2];
  
  var isValidNum  = isNumber(phoneNum) && (phoneNum.length == 10) && (firstNum!="1") && (firstNum!="0") && (areaCode!="900") && (areaCode!="976") && (prefix!="555")

  return isValidNum;
  
}

function isCreditCard(cardNum,cardType){
  
  if (!isNumber(cardNum)){ return false; }
  
  switch (cardType){
    case "visa":
	  if (cardNum.length == 16 || cardNum.length == 13)
	  	{ 
			if (cardNum.substr(0,1) == "4")
				return true; 
		}
	  break;
	case "diners":
	  if (cardNum.length == 14 )
	  	{
			if (cardNum.substr(0,3) == "300" || cardNum.substr(0,3) == "305" || cardNum.substr(0,2) == "53" || cardNum.substr(0,2) == "36" || cardNum.substr(0,2) == "38")			
				return true; 
		}
	  break;
	case "mc":
	  if (cardNum.length == 16 )
	  	{
			if (cardNum.substr(0,2) == "51" || cardNum.substr(0,2) == "52" || cardNum.substr(0,2) == "53" || cardNum.substr(0,2) == "54" || cardNum.substr(0,2) == "55")			
				return true; 
		}
	  break;
	case "discover":
	  if (cardNum.length == 16 )
	  	{
			if (cardNum.substr(0,4) == "6011")
				return true; 
		}
	  break;
	case "amex":
	  if (cardNum.length == 15 )
	  	{ 
			if (cardNum.substr(0,2) == "34" || cardNum.substr(0,2) == "37")
				return true; 
		}
	  break;
    default:
	  return false;
	  break;
  }
  return false;
  
}


function validExpDate(expDate)
{	
	
	
	var objRegExpDateFormat = /^(\d{1,2})\/(\d{2}|\d{4})$/;
	
	if(objRegExpDateFormat.test(expDate))
	{
		var expDateArray = expDate.match(objRegExpDateFormat);
		
		var monthField = parseInt(expDateArray[1], 10);
		var yearField = parseInt(expDateArray[2], 10);
		
			
		var today = new Date();
		var currentYear = parseInt(today.getFullYear().toString(), 10);
		
				
		if (monthField > 0 && monthField < 13)
		{ 	
		
			if (expDateArray[2].length == 2)
			{
				if (yearField < 70)
				
					yearField = yearField + 2000
				else
					yearField = yearField + 1900;
			}
			
			
			var currentYearNum = parseInt(currentYear, 10);
						
			if ( currentYearNum < yearField)
			{	
				return(true);
			}	
			else 
			{	
				
				if (currentYearNum == yearField)
				{
					if (parseInt(today.getMonth().toString(), 10) < expDateArray[1])
						return(true);
				}
				
				return(false);
			}								
		}
		
		else 
		{
			return(false);
		}			
	}
	else
	{
			return(false);
	}
	
	
	
} 


function isCapID(capID){
  if (capID.length==10 && isNumber(capID)){
    return true;
  }
  return false;
}

function isReportNum(ReportNum){
  if (ReportNum.length==10){
    return true;
  }
  return false;
}

function isInvestigationNum(InvNum){
  if (InvNum.length==2){
    return true;
  }
  return false;
}



function formCheck(cookieArray, lowerBound, upperBound){

  
  var i
  for (i=lowerBound; i < upperBound + 1; i++){
	
    if (isInList (i, requiredList)){
	  if ( (cookieArray[i][1] == "") || isBlank(cookieArray[i][1])){
	   return false;
	   }
	}
	
	if (isInList (i, xalphaList)){
	  if ( !(isXAlpha(cookieArray[i][1]))){
	   return false;
	   }
	}
	if (isInList (i, numberList)){
	  if ( !(isNumber(cookieArray[i][1]))){
	   return false;
	   }
	}
	
	if (isInList (i, phoneList)){
	  if ( !(cookieArray[i][1]=="//") && !isPhone(cookieArray[i][1])){
	   return false;
	   }
	}
	
	if (isInList (i, zipList)){
	
	  if (i==27){
	  	
		if(cookieArray[i][1] != "" && !isZip(cookieArray[i][1] ) )
			return false;
			
	    if (!isZip(cookieArray[i][1]) && additionalPartialFill(cookieArray)){
		return false; 
	   }
	  
	  } else if (i==35){
	  	
		if(cookieArray[i][1] != "" && !isZip(cookieArray[i][1] ) )
			return false;
		
	    if (!isZip(cookieArray[i][1]) && cardPartialFill(cookieArray)){
		return false;
	   }
	  
	  } else if (!isZip(cookieArray[i][1])){ 
	    return false;
	   }
	  
	}
	  	  
	
	if (isInList (i, socNumList)){
	  if (!isSSN(cookieArray[i][1])){
	   return false;
	   }
	}
	
	if (isInList (i, creditCardList)){
	  if ( !isCreditCard(cookieArray[i][1],cookieArray[i-1][1]) ){
	   return false;
	   }
	}
	if (isInList (i, expDateList)){
	  if ( !validExpDate(cookieArray[i][1]) ){
	   return false;
	   }
	}
	if (isInList (i, alphaNumList)){
	  if ( !isAlphaNum(cookieArray[i][1]) ){
	   return false;
	   }
	}
	if ((i == 6)||(i==32)){
	  if ( !isAlphaNum(cookieArray[i][1]) ){
	   return false;
	   }
	}
	
	if (isInList (i, dateList)){
	  if (!isBlank(cookieArray[i][1]) && (!isDate(cookieArray[i][1]) || !isMinMaxAge(cookieArray[i][1]))){
	   return false;
	   }
	}
  }
  
  return true;

}
function abbrevFormCheck(cookieArray, lowerBound, upperBound){
  
  var i
  for (i=lowerBound; i < upperBound + 1; i++){
	
    if (isInList (i, abbrevReqList)){
	  if ( (cookieArray[i][1] == "") || isBlank(cookieArray[i][1])){
	   return false;
	   }
	}
	
	
	if (isInList (i, reportIdList)){
	  if (!isCapID(cookieArray[i][1]) ){
	   return false;
	   }
	}
		
	if (isInList (i, numberList)){
	  if ( !(isNumber(cookieArray[i][1]))){
	   return false;
	   }
	}
	
	if (isInList (i, zipList)){
	
	  if (!isZip(cookieArray[i][1])){ 
	    return false;
	   }
	  
	}
		
	if (isInList (i, socNumList)){
	  if (!isSSN(cookieArray[i][1])){
	   return false;
	   }
	}
	if (isInList (i, invList)){
	  if (!isInvestigationNum(cookieArray[i][1]) || !isNumber(cookieArray[i][1])){
	        return false;
	  }
	}  

  }
  return true;
}


function disputeFormCheck(cookieArray, lowerBound, upperBound){

  var i
  for (i=lowerBound; i < upperBound + 1; i++){
	
    if (isInList (i, disputeReqList)){
	  if ( (cookieArray[i][1] == "") || isBlank(cookieArray[i][1])){
	   return false;
	   }
	}
	
	if (isInList (i, numberList)){
	  if ( !(isNumber(cookieArray[i][1]))){
	   return false;
	   }
	}
	
	if (isInList (i, reportIdList)){
	  if (!isCapID(cookieArray[i][1]) ){
	   return false;
	   }
	}
	
	if (isInList (i, zipList)){
	
	  if (!isZip(cookieArray[i][1])){ 
	    return false;
	   }
	  
	}
		
	if (isInList (i, socNumList)){
	  if (!isSSN(cookieArray[i][1])){
	   return false;
	   }
	}
  }
  return true;
}





function IsRegEmailValid(emailValue)
{
alert("email value:(" + emailValue + ")");
var EmailOk  = true
var AtSym    = emailValue.indexOf('@')
var Period   = emailValue.lastIndexOf('.')
var Space    = emailValue.indexOf(' ')
var Length   = emailValue.length - 1   

if ((AtSym < 1) ||                     
    (Period <= AtSym+1) ||             
    (Period == Length ) ||             
    (Space  != -1))                    
   {  
      EmailOk = false
   }
return EmailOk
}



function IsEmailValid(FormName,ElemName)
{
var EmailOk  = true
var Temp     = document.forms[FormName].elements[ElemName]
var AtSym    = Temp.value.indexOf('@')
var Period   = Temp.value.lastIndexOf('.')
var Space    = Temp.value.indexOf(' ')
var Length   = Temp.value.length - 1   

if ((AtSym < 1) ||                     
    (Period <= AtSym+1) ||             
    (Period == Length ) ||             
    (Space  != -1))                    
   {  
      EmailOk = false
      alert('The email address you gave us is not valid. Please check your information and enter the exact same email address in each box.')
      Temp.focus()
   }
return EmailOk
}

function removeInvalidCharacters(testString)
{
	var returnString = "";
    for (i=0;i<testString.length;i++){
	  c = testString.substr(i,1);
	  if ( c=="." ){
		
	  }
	  else
	  {
	  	  returnString = returnString + c;  
	  }
    }
    return returnString;
}

function removeCommas(testString)
{
	
	var returnString = "";
    for (i=0;i<testString.length;i++){
	  c = testString.substr(i,1);
	  if ( c=="," ){
		
	  }
	  else
	  {
	  	  returnString = returnString + c;  
	  }
    }
    return returnString;
}

function within60Days(dateString)
{
    if (!isDate(dateString))
        return false;
    
    var now = new Date();
    var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var thisDay = today.getTime();
    var thatDay = Date.parse(dateString);
    var inDay = new Date(thatDay);
    
    if (thatDay > thisDay)
        return false;
    
    var diffDate = new Date(thisDay - thatDay);
    
    if (diffDate.getFullYear() == "1969")
        return true;
    
    if (diffDate.getMonth() > 2)
        return false;
    
    if (diffDate.getMonth() == 2 && diffDate.getDate() > 1)
        return false;
    
    return true;
}


function lTrim(str) {
  var whitespace = new String(" \t\n\r");
  var s = new String(str);

  if (whitespace.indexOf(s.charAt(0)) != -1) {
    var j=0, i = s.length;

    while (j < i && whitespace.indexOf(s.charAt(j)) != -1)
      j++;

    s = s.substring(j, i);
  }
  return s;
}

  
function rTrim(str) {
  var whitespace = new String(" \t\n\r");
  var s = new String(str);

  if (whitespace.indexOf(s.charAt(s.length-1)) != -1) {
    var i = s.length - 1;
    while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1)
      i--;
    s = s.substring(0, i+1);
  }
  return s;
}


function trim(str) {
  return rTrim(lTrim(str));
}

  