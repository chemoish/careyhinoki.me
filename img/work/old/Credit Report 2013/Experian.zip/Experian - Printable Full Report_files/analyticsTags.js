if(typeof(window.scTagged) === 'undefined') {
	document.write('<script language="JavaScript" ' +
		'type="text/javascript" ' + 
		'src="https://www.experian.com/js/s_code.js">' +
		'</scr' + 'ipt>');
	document.write('<script language="JavaScript" ' +
		'type="text/javascript" ' + 
		'src="/consumer/scripts/analyticsTags_inc.js">' +
		'</scr' + 'ipt>');
}
scTagged = 1;
