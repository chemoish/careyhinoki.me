
var logoutMsg0 = "You are about to leave the Experian site.\nAre you sure that you have printed, saved or written down any information that you may want for your records and that you are ready to logout?\n"
var logoutMsg1 = "LOGOUT will conclude your visit to our Web site. Are you sure that you have printed, saved or written down any information that you may want for your records and that you are ready to logout?\n"
var logoutMsg2 = "To Print or Save a copy of your report, select the \"Print your report\" link in the Credit Report Toolkit, and use your browser's Print or Save As feature from the File menu.\n"
var logoutMsg3 = "\nTo return to your Experian report in the near future, log on to www.experian.com/consumer and select \"View your report again\" or \"Dispute\" and enter your Report Number.\n"
var logoutACRMsg0 = "Select the OK button below to conclude your visit to our Web site and to return to AnnualCreditReport.com. You are required to return to the AnnualCreditReport.com Web site if you still need to view your credit report from Equifax or TransUnion.\n"
var logoutACRMsg1 = "\nBe sure that you have printed, saved or written down your Experian Report Number. ";
var logoutACRMsg2 = logoutMsg2;
var logoutACRMsg3 = logoutMsg3;
var logoutACRMsg4 = "\nIf you are not yet ready to leave our site, select the Cancel button.\n"

var field_length=0;
function TabNext(obj,event,len,next_field) {
	if (event == "down") {
		field_length=obj.value.length;
		}
	else if (event == "up") {
		if (obj.value.length != field_length) {
			field_length=obj.value.length;
			if (field_length == len) {
				next_field.focus();
				}
			}
		}
	}


function getSecuredURL(currentURL, fileName)
{
	
	var regexp = /http:/; 
	var securedURL = currentURL.replace(regexp, "https:");
	securedURL = securedURL.slice(0, securedURL.lastIndexOf("/")+1); 
	securedURL = securedURL + fileName; 

	return securedURL;	
}

function helpWindow(fileName)
{
window.open("../help/"+fileName+".html", "WIN",
		"status=no,toolbar=yes,location=no,menubar=yes,width=567,height=500,scrollbars=yes,resizable=no,directories=no,");
}

function closeHelp()
{
	window.close();
}


   var initWidth  = window.innerWidth;
   var initHeight = window.innerHeight;
  
  function bogusResize(){
    if (navigator.appName ==  'Netscape'){
	  if ((window.innerWidth != initWidth) || (window.innerHeight != initHeight)){
	    location.reload();
	  }
    }
  }

  
  function underInvestigation(fileName)
  {
  	if (itemUnderInvestigation)
	{
  	alert ("An investigation is already in progress\nfor this item. Investigations may take up\nto 30 days. You will be hearing from us\nafter we receive the results.");
	}
	else
	{
		document.location = fileName;
	}
  }
  
 function logoutConfirmInvSummary()
  {
  	if (confirm("LOGOUT will conclude your visit to our Web site.\nAre you sure that you have printed, saved\nor written down any information that you\nmay want for your records and that you\nare ready to logout?"))
	{
		document.location.href ="Logoff.do";
	}
  }
  
 function logoutConfirm()
 {
	type = (logoutConfirm.arguments.length >= 1) ? logoutConfirm.arguments[0] : "";

	if( type != "" && type == "reseller")
	{
		if (confirm(logoutMsg1 + logoutMsg2))
		{
			document.location.href ="Logoff.do";
		}
	}
	else if( reseller != null && reseller == true )
	{
		 if (confirm(logoutMsg1 + logoutMsg2))
		{
			document.location.href ="Logoff.do";
		}
	}
	else
	{
		if (confirm(logoutMsg1 + logoutMsg2 + logoutMsg3))
		{
			document.location.href ="Logoff.do";
		}
	}
 }


function  returnToResellerHomeConfirm()
{
    if (confirm("Reseller Home will allow you to enter disputes for another consumer, view results of previous investigations, or view information about our Express Request service. Are you sure you want to return to Reseller Home?"))
    {
		document.location.href ="ResellerHome.do";
    }
}

function returnToCentralSource(page)
{
	if(page == 'reportPage') {
		if (confirm(logoutACRMsg0 + logoutACRMsg1 + logoutACRMsg2 + logoutACRMsg3 + logoutACRMsg4))
		{
			return true;
		} else {
			return false;
		}
	} else {
		if (confirm(logoutACRMsg0 + logoutACRMsg4))
		{
			return true;
		} else {
			return false;
		}
	}
 }

function goBack(lastURL){

  if (lastURL==""){
    history.go(-1);
  } else {
    document.location = lastURL; 
  }
}

function ja_rollover(imageName){

  if (document.images){
   
    eval("document." + imageName + ".src=" + imageName + "_on.src");

  }

}

function ja_restore(imageName){

  if (document.images){
   
    eval("document." + imageName + ".src=" + imageName + "_off.src");

  }

}

function ja_rollover_preload(){
  
  if (document.images){

    for (i=0; i<arguments.length;i++){

      eval(arguments[i] + "_off=new Image()")
      eval(arguments[i] + "_off.src = '../images/"+ arguments[i] + "_off.gif'")
      eval(arguments[i] + "_on=new Image()")
      eval(arguments[i] + "_on.src = '../images/"+ arguments[i] + "_on.gif'")

    }

  }

}

function ja_showHideLayers()
{
    
    var args = ja_showHideLayers.arguments;
	var argVal = "";
	
	for (index=0; index < args.length; index++)
    {
	
	  var layerString = "";
			
	  do
      {
	  
	    argVal = args[index];
	  
	    if ( argVal != 'visible' && argVal != 'hidden')
        {
		  
          if (navigator.appName.indexOf("Netscape") != -1) 
          {
          
            if (parseInt(navigator.appVersion) >= 5) 
            {
		  
		      layerString = "document.getElementById('" + argVal + "').style.";
		  
            }
		    else if (document.layers)
            {
		  
		      layerString += "document.layers['" + argVal + "'].";
		  
		    }
          }
          else if (document.all) 
          {
		  
		    layerString = "document.all." + argVal + ".style.";
		  		   
	      }
		
		  index++;
		
	    }
	  	  	  
	  }
      while ( argVal != 'visible' && argVal != 'hidden');
	  
	  eval(layerString + "visibility = '" + argVal + "'");
	  
	}
	
  }
  
  function personalSubmit(layerName, formName)
  {
  
    if (navigator.appName.indexOf("Netscape") != -1) 
    {
          
      if (parseInt(navigator.appVersion) >= 5) 
      {
	
	    document.forms[formName].submit();
      
      }
		  
      else if (document.layers) 
      {
	
	    document.layers[layerName].document.forms[formName].submit();
      
      }
	
	}
    else if (document.all) 
    {
	  	
	  document.all[formName].submit();
	
	}
   
  }
  
 

function openWindow(fileName)
{
	window.open(fileName);
}




function fixDate(date) {
  var base = new Date(0);
  var skew = base.getTime();
  if (skew > 0)
    date.setTime(date.getTime() - skew);
}

function generateFooter() {
    var curDate = new Date(); 
    fixDate(curDate); 
    document.write("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr>");
    document.write("<td  align=\"center\" class=\"footer\">&copy;Experian " + (curDate.getFullYear()) + ". All rights reserved.<br>");
    document.write("Experian and the marks used herein are service marks or registered trademarks of Experian.<br>");
    document.write("Other product and company names mentioned herein may be the trademarks of their respective owners.</font></td></tr></table>");
	document.write('<script language="JavaScript" ' +
			'type="text/javascript" ' + 
			'src="/consumer/scripts/analyticsTags.js">' +
			'</scr' + 'ipt>');
}

function changeFromCDFtoCDIConfirm()
 {
  msg_1='Are you finished reviewing the results of your investigation? Be sure to print, save or write down any information that you may want for your records before leaving this page to view a complete copy of your corrected credit report. To Print or Save the results of your investigation, use your browser\'s Print or Save As feature from the File menu. To view your results again after you leave this page, select the View the results of a dispute link on experian.com/consumer.' 
  if (confirm(msg_1))
	{
		document.location.href ="RequestCDIByCAPID.do";
	}
}
